unzip file 

open cmd 

go to the location of the file

run file

python bikeshare.py 


data files :- https://drive.google.com/drive/folders/170ClKDAcl4njpULdIQdeTdjslLm7Acow?usp=sharing
